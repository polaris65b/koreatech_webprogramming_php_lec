create table friend (
    num int not null auto_increment,
    name char(20) not null,
    tel char(20) not null,
    address char(80),
    primary key(num)
);
